<?php
$prefix = array(
  'aren\'t',
  'isn\'t',
  'not'
);
