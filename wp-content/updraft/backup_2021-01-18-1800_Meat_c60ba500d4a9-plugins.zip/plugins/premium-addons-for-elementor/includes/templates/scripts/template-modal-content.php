<?php
/**
 * Templates Loader View
 */
?>
<div class="premium-filters-list"></div>
<div class="premium-templates-wrap">
	<div class="premium-keywords-list"></div>
	<div class="premium-templates-list"></div>
</div>