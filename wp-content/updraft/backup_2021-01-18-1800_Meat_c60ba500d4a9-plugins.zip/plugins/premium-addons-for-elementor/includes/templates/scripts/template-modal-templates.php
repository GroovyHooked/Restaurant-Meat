<?php
/**
 * Templates Modal Container
 */
?>
<div id="premium-modal-templates-container"></div>